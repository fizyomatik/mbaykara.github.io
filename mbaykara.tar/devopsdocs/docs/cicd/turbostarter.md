---
template: overrides/main.html
title: Turbostarter
---

# Turbostarter

Turbostarter is a small web-based tool to create frontline cloud instances. Even though what happens under the hood is quite complex when creating cloud instances, turbostarter abstracts from all this and enables non-technical people to deploy them with ease. Behind each cloud server there is a project in git housing its configuration. To be precise, the CI of those projects does the actual deployment and turbostarter only creates those git projects. But the whole deployment procedure (Turbostarter, CI, Flux) is often referred to as 'turbostarter'.

![!Turbostarter](../assets/images/cicd/turbostarter.png)

Turbostarter has three main modes of operation:

* **Productive** - Used to deploy productive server instances to the cloud. A valid license key is needed to do so. The name of the project is derived from the license key.
* **Development** - Used to deploy development server instances to our local cloud (only reachable internally). Every developer can do this without a license key and the project name can be freely choosen.
* **One-Shot** - Everybody can use this feature to deploy ephemeral test instances running for a day. After that period the server is automatically stopped and deleted.

Apart from that, turbostarter is RBAC enabled and what you can do with it depends on your permissions and roles.


## Frontline Git Projects

As mentioned before a git project is used per customer server to configure it. Turbostarter creates them by forking from a central template project. The template projects has multiple branches and each branch can be used to create a different kind of configuration project. E.g. there is a 'dev' branch where all development projects originate from and there is a 'saas' branch where all productive saas projects are based on. With that concept each resulting project can have a completely different behaviour/CI.

### Structure

The structure of the git projects looks like follows:

```
.
├── config                               # Stores custom configuration for that specific project
│   ├── frontline-command-center
│   │   └── configuration                # Files stored here end up in the UBIMAX_HOME folder under /config/configuration
│   │       ├── external_links.json
│   │       └── xserver.properties
│   ├── frontline-connector              # Files stored here end up in the UBIMAX_HOME folder under /config/configuration
│   │   └── configuration
│   │       └── xservice.properties
│   ├── frontline-workplace              # Whitelabeling configuration for frontline workplace
│   │   ├── apk
│   │   ├── config.json
│   │   └── sdcard
│   │       └── app_config.yaml
│   ├── keycloak
│   │   └── broker                       # Identity brokers for keycloak can be added here
│   │       └── microsoft.yaml
│   └── values.custom.yaml
├── helm                                 # This folder extends the frontline helm chart providing some bases values
│   ├── flux-helm-release.yaml
│   └── frontline-turbostarter
│       ├── Chart.lock
│       ├── Chart.yaml
│       └── values.yaml
├── project.cfg.yaml                     # Turbostarter project config file
├── README.md
├── turbostarter                         # Turbostarter config folder used to store permissions and define getters/setters
│   ├── form.js
│   ├── formPermissions.yaml
│   ├── getter.js
│   └── setter.js
└── values.yaml                          # Helm values.yaml containing the project configuration values
```

When applying changes to the project with turbostarter most of the files will be automatically updated to their latest version based on the template project, so manual changes applied to them before will just be overwritten. The folder 'config' and the values.yaml will not be touched. They are meant to store project specific configuration. There are some configuration files not editiable with the turbostarter web interface mostly used for special configuration cases, e.g. the `/config/keycloak/broker/` folder. Those folders need to be handled manually using git. But if you want to do this, you should really know what you are doing.

### CI Pipeline

The CI pipeline of the projects rougly looks like follows. As mentioned before each project type (dev, saas, ...) is based on a different branch in the template project and therefore could have an entire different CI. But this is what most of the projects share:

``` mermaid
graph LR
  ensure(Ensure Infrastructure) --> before-build( )
  computer(Computer Values) --> before-build( )
  before-build( ) --> build-fcc(Build Frontline Command Center)
  before-build( ) --> build-fc(Build Frontline Connector)
  before-build( ) --> build-fwp(Build Frontline Workplace)
  build-fcc(Build Frontline Command Center) --> before-deploy( )
  build-fc(Build Frontline Connector) --> before-deploy( )
  build-fwp(Build Frontline Workplace) --> before-deploy( )
  before-deploy --> deploy(Deploy Flux)
  deploy --> stop(Stop Flux)
  deploy --> delete(Delete Flux)
  style before-build fill:#fff,stroke:#000,stroke-width:1px
  style before-deploy fill:#fff,stroke:#000,stroke-width:1px
  style deploy color:#000,stroke-dasharray: 5 5
  style stop color:#000,stroke-dasharray: 5 5
  style delete color:#000,stroke-dasharray: 5 5
```
<div style="text-align: right"><small><i>Dashed nodes are manual jobs</i></small></div>

* **Ensure Infrastructure** - This step makes sure that the neccessary infrastructure to run the server instances is there. Which infrastructure all dependent services are meant like databases, file storages, keycloak realms etc.
* **Compute Values** - Some project wide values needed in subsequent stages are computed in this step. They are also being attached as artificats to the pipeline for debugging purposes.
* **Build Frontline Command Center** - The FCC config stored under `config/` is bundled, hashed and stored on azure bob storage
* **Build Frontline Connector** - The FCC config stored under `config/` is bundled, hashed and stored on azure bob storage
* **Build Frontline Workplace** - The configured Frontline Workplace version is downloaded and whitelabled with the configuration stored under `config/` and uploaded to azure blob storage afterwards
* ***Deploy Flux*** - The project with all its configuration, version references and links to the previously created blobs is bundled into a HelmRelease CRD and checked in into the corresponding flux repository so that flux will deploy it shortly afterwards
* ***Stop Flux*** - The HelmRelease CRD will be removed from the flux repository which leads to flux undeploys that server. The customer data will be retained.
* ***Delete Flux*** - The project will be deleted. All infrastructure created in the *ensure infrastructure* step will be deleted and the git project will be converted into an archive.

<div style="text-align: right"><small><i>Italic means manual job</i></small></div>

!!! caution
    As already mentioned before, turbostarter projects can have a different logic depending on their environment. Thus please note that on development projects the stop job always **deletes all data**. This means dev servers cannot be stopped without loosing their data.

## SLA

The Turbostarter SLA guarantees a service disruption of 24h at a max (including the CI of the underlying Frontline Git Projects). Please refrain from creating high prio tickets targeting the turbostarter within that timeframe. That SLA was aligned with the Customer Success and Project Engineering departments. If you do not agree with it please reach out to their corresponding team leads.

## General

If a new service should be added to our cloud offerings please keep in mind that it somehow has to be aligned to our current deployment model with turbostarter. Sometimes dozens of servers are deployed/undeployed to the cloud within a week. Therefore we put quite some effort into automating this. New products have to somehow follow this approach. It is not feasible to publish new services which need frequent manual interaction by engineers to make them available to customers.
