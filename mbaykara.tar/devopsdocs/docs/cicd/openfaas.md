---
template: overrides/main.html
title: OpenFaaS
---

# OpenFaaS

[OpenFaaS][1] is a serverless computing framework which can be run in kubernetes. We essentially use it as an add-on for our CI to run certain tasks. Currently it is used by the [turbostarter][2] projects to provision new customers to our cloud (creating Keycloak realms, configuring Frontline Apps tenants and creating infrastructure in general). OpenFaaS has an integrated message broker based on [NATS][3] which can be leveraged to notify multiple functions at once upon certain events. Generally, the advantages of OpenFaaS compared to the traditional GitLab CI are:

* It is more easily accessible, e.g. if a piece of logic needs to be executed everytime a new customer arrives on our cloud we simply have to write a function and add it to the NATS messaging bus. No interference with the CI itself or other functions.
* Currently the functions are called by the CI but theoretically they can be called from anywhere. This adds a lot of flexibility for the future: OpenFaaS could directly be called from the license server once a new cloud license has been created. This means infrastructure would be ready even before creating the turbostarter project.
* In the future each license will have a set of resources assigned to it (in contrast to each turbostarter project which is the case now). Handling this in the classic CI is a quite tedious task. OpenFaaS functions simplify this a lot.
* The FCC CI could be integrated with OpenFaaS as well eliminating the need of having a seperate setup process for FCC branches. The FCC instances would then benefit from all improvements added to the functions as well, e.g. they would automatically be connected with Keycloak, Frontline Apps, AIStudio and everything else set up by OpenFaaS.

!!! info

    One general thing we have to have in mind is: The OpenFaaS functions are completely decoupled from the underlying GitLab pipeline and run asynchronously in the background. This has advantages and disadvantages at the same time: Infrastructure related errors will not block the entire pipeline anymore which means version or configuration updates via the turbostarter are a lot more failsafe. However, this also means errors are not as clearly visible anymore as they would be when being part of the classic CI. Even if a crucial part of infrastructure fails to be created the pipeline still succeeds. We have a monitoring mechanism in place which informs us about failed functions, but still errors are a bit harder to track now.

  [1]: https://www.openfaas.com/
  [2]: turbostarter.md
  [3]: https://nats.io

## Integration with Frontline Git Projects

As already stated the CI currently calls the OpenFaaS functions. This is done via [webhooks][4] provided by GitLab. More precisely: **Job Event** webhooks which are called everytime the state of a pipeline job changes. A special OpenFaaS function listens for those events and waits until one of the following events are received to take further actions:

  [4]: https://docs.gitlab.com/ee/user/project/integrations/webhooks.html

* **ensure-infrastructure** - Once ensure-infrastucture finishes successfully, a create event is dispatched to the NATS message bus.
* **delete-flux** - Once delete-flux finishes successfully, a delete event is dispatched to the NATS message bus.


## Functions overview

The following functions are currently present in our OpenFaaS CI add-on environment:

* **Afterburner** - Listens for GitLab webhooks and dispatches NATS events accordingly
* **KeyProvi** - Listens for NATS events created by afterburner and accordingly creates/deletes realms on keycloak. Subsequently dispatches new events.
* **FlappsProvi** - Listens for NATS events created by KeyProvi and accordingly creates/deletes tenants on Frontline Apps using the ```/license``` endpoint.
* **IBro** - Listens for NATS events created by KeyProvi and accordingly creates/deletes identity brokers on Keycloak.
* **Keykericli** - Listens for NATS events created by KeyProvi and accordingly creates clients on Keycloak.
* **FuidGen** - Generates Frontline UUIDs (FUIDs) based on the license. This is the single source of truth when it comes to those IDs which means all CI services using FUIDs have to talk with this function.


### Process Flow

The process flow rougly looks like this:

``` mermaid
graph LR
 gitlab(Gitlab Job Webhook) --> afterburner(Afterburner)
 afterburner(Afterburner) --> turbostarter-event(Turbostarter-Event)
 afterburner(Afterburner) -.-> fuidgen(FuidGen)
 fuidgen(FuidGen) -.-> afterburner(Afterburner)
 turbostarter-event(Turbostarter-Event) --> keyprovi(KeyProvi)
 keyprovi(KeyProvi) --> keyman-event(Keyman-Event)
 keyman-event(Keyman-Event) --> flappsprovi(FlappsProvi)
 keyman-event(Keyman-Event) --> ibro(IBro)
 keyman-event(Keyman-Event) --> keykericli(Keykericli)

 style gitlab fill:#FCA326,color:#000000,stroke: 5 5
 style turbostarter-event fill:#fff,color:#000,stroke-dasharray: 5 5
 style keyman-event fill:#fff,color:#000,stroke-dasharray: 5 5
```
<div style="text-align: right"><small><i>Dashed nodes are NATS events</i></small></div>
