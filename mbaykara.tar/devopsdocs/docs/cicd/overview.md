---
template: overrides/main.html
title: CI/CD 
---

# CICD 

Continous integration and continous delivery/deployment are integral parts of our development process and operations. As a CI system we use Gitlab CI as part of our Gitlab installation. Gitlab CI executes all tasks in a Kubernetes cluster which scaled based on the load. That cluster is not exclusively used for CI build jobs but can rather be seen as a general task processor for any type of automation task.
