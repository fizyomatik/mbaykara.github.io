---
template: overrides/main.html
title: Infrastructure
---

# Infrastructure

All the infrastructure needed to operate Frontline is hosted at our cloud provider [Microsoft Azure][1]. We create it following the **infrastructure as code** aproach using [Terraform][2].

Our Azure tenant is devided into four subscriptions:

* Production (6993c852-1d01-41e5-9268-ac63e00ad1c2)
* Development (00c53961-2488-40ca-a343-bbad49455ab6)
* Internal (ee3e92bb-742c-4da3-9e74-b1c9c04c84c6)
* Playground (88a71713-e555-47c8-89e8-8b4fdb80a2d2)

Each subscription serves a different purpose which can already be roughly derived from its name. A detailed explaination can be found in the Azure section.

  [1]: https://azure.microsoft.com/
  [2]: terraform.md
