---
template: overrides/main.html
title: Terraform
---

# Terraform

[Terraform][1] is an infrastructure as code (IaC) tool that allows you to build, change, and version infrastructure safely and efficiently. We use it to maintain our infrastructure on Azure.


!!! info

    Creating resources manually with the Azure CLI or Azure Portal should only be done for evaluation purposes during the development phase (in the [Playground subscription][2]). Once something should be used productively it has to be transformed into a terraform configuration.

Terraform stores all information about the infrastructure in a so called state file. This state file keeps track of resources created by your configuration and maps them to real-world resources. To collaboratively work with terraform the state file has to be stored on a central location and guarded by a locking mechanism so that it can only be modified by one terraform process at a time.

We use GitLab as this kind of managed terraform remote backend and not only store the state file there but also use its CI to apply the changes with terraform. Each Azure subscription has its own independent git project under the 'Cloud Infrastructure' group in GitLab.

  [1]: https://www.terraform.io/
  [2]: azure/playground-subscription.md
