---
template: overrides/main.html
title: Frontline Cloud 
---

# Frontline Cloud

Everything related to our public cloud offerings is covered by this section. Our cloud service can be roughly devided into the following areas:

* Customer cloud available at [frontlineworker.com][1]
* Global distributed [WebRTC][2] services based on [coturn][3] and [mediasoup][4]
* AI model training & serving based on [kfserving][5]

Apart from that there are also smaller services like for example a PDFMake and a few others.

  [1]: https://frontlineworker.com
  [2]: https://webrtc.org/
  [3]: https://github.com/coturn/coturn
  [4]: https://github.com/versatica/mediasoup/
  [5]: https://github.com/kubeflow/kfserving
