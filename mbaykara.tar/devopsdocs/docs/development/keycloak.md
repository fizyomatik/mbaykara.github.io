---
template: overrides/main.html
title: Keycloak Development Setup
---

# Keycloak
To be able to use Keycloak during development you either have to install Keycloak locally on your computer or use our development environment. In either case you have to create and configure a realm, more precisely one realm per Frontline domain.

## Configuration

### Realm
On a local installation you have to create a realm manually. All necessary steps to get this going are covered by the [on-premise installation guide][1]. In most cases a local installation is not really required and our development environment can be used instead. It is reachable under https://auth1.svc.frontline.rocks and much easier to use. There is an automation implemented by a serverless function which creates and configures a realm for you including the clients, identity brokering and so on. In fact, the realm is configured with exactly the same logic used in our prod environment.

To use the automation the only thing you have to do is to issue a HTTP `POST` request to the following URL and set the below query parameters: `https://functions.frontline.rocks/function/lopro`

* `name` has to be set to a arbitrary name identifying your local installation
* `url` has to be set to the URL under which your local FCC will be reachable

The function will then return a unique realm name to you.

!!! caution "Dev Environment Realms"

    The realms in the dev environment wont stay forever. They can be cleaned up at any tome to guarantee a smooth dev environment. If you need your realm for a long time please consider installing keycloak locally on your computer.

Once you are done please delete your realm by issuing the same request as a HTTP `DELETE`.

### Properties

The following properties have to be configured in the FCC and <realm\> has to be set to your realm:

xserver.properties
```
fcc.keycloak.enabled=true
fcc.keycloak.keyman.override-realm=<realm>
fcc.keycloak.keyman.uri=https://auth.svc.frontline.rocks/v2/
fcc.keycloak.keyman.http-basic-auth-user=keyman
fcc.keycloak.keyman.http-basic-auth-password=123
```

!!! tip "Debugging"
    For debugging purposes consider setting the following additional property:

    ```
    fcc.keycloak.debug=true
    ```

### Multi Domain Setup

In a multi domain setup you have to create one realm per domain. The HTTP request to do so varies a bit from above. Instead of providing a arbitrary `name` the license ID of each license has to be passed as `license` parameter. This means in total you have to pass the following query parameters:

* `license` the license key
* `url` has to be set to the URL under which your local FCC will be reachable

!!! caution "Licenses"

    For a multi domain setup you need two newly created licenses from the dev license server. The default development license will not work!

Afterwards it is recommended to disable the debug feature to prevent the insertion of demo data in your local FCC instance by setting the following environment variable (not property):

```
FCC_NO_DEBUG: true
```

and disable the default domain to have a domain selection dialog on the login page via the following property:

```
xserver.domain.enableDefault=false
```

Now you can login to your FCC as sysadmin, request the licenses on the admin page and use them with Keycloak afterwards.

## Dev Environment Web Interface

You usually do not need to access the Keycloak admin console. But if you want to you can reach it under the following URL: https://auth1.svc.frontline.rocks/auth/admin . To get access please contact the Frontline DevOps team.


[1]: ../../cloud/identity/on-premise/
